﻿
namespace Курсовая_Работа
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelVopros = new System.Windows.Forms.Label();
            this.labelNumVopros = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.radioButtonO1 = new System.Windows.Forms.RadioButton();
            this.radioButtonO2 = new System.Windows.Forms.RadioButton();
            this.radioButtonO3 = new System.Windows.Forms.RadioButton();
            this.radioButtonO4 = new System.Windows.Forms.RadioButton();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.buttonSLV = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1Number = new System.Windows.Forms.Label();
            this.checkBoxO1 = new System.Windows.Forms.CheckBox();
            this.checkBoxO2 = new System.Windows.Forms.CheckBox();
            this.checkBoxO3 = new System.Windows.Forms.CheckBox();
            this.checkBoxO4 = new System.Windows.Forms.CheckBox();
            this.checkBoxO5 = new System.Windows.Forms.CheckBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelO1 = new System.Windows.Forms.Label();
            this.labelO2 = new System.Windows.Forms.Label();
            this.labelO3 = new System.Windows.Forms.Label();
            this.labelO4 = new System.Windows.Forms.Label();
            this.labelO5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label1V = new System.Windows.Forms.Label();
            this.label2V = new System.Windows.Forms.Label();
            this.label3V = new System.Windows.Forms.Label();
            this.label4V = new System.Windows.Forms.Label();
            this.label5V = new System.Windows.Forms.Label();
            this.buttonZT = new System.Windows.Forms.Button();
            this.chartRes = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.buttonPrint = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartRes)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(973, 510);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(175, 139);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelVopros
            // 
            this.labelVopros.AutoSize = true;
            this.labelVopros.BackColor = System.Drawing.Color.Turquoise;
            this.labelVopros.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelVopros.Location = new System.Drawing.Point(71, 204);
            this.labelVopros.Name = "labelVopros";
            this.labelVopros.Size = new System.Drawing.Size(66, 24);
            this.labelVopros.TabIndex = 1;
            this.labelVopros.Text = "label1";
            // 
            // labelNumVopros
            // 
            this.labelNumVopros.AutoSize = true;
            this.labelNumVopros.BackColor = System.Drawing.Color.White;
            this.labelNumVopros.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelNumVopros.Location = new System.Drawing.Point(72, 82);
            this.labelNumVopros.Name = "labelNumVopros";
            this.labelNumVopros.Size = new System.Drawing.Size(92, 24);
            this.labelNumVopros.TabIndex = 2;
            this.labelNumVopros.Text = "Вопрос - ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-4, -2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1166, 664);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(738, 182);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(392, 263);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // radioButtonO1
            // 
            this.radioButtonO1.AutoSize = true;
            this.radioButtonO1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonO1.Location = new System.Drawing.Point(75, 243);
            this.radioButtonO1.Name = "radioButtonO1";
            this.radioButtonO1.Size = new System.Drawing.Size(133, 28);
            this.radioButtonO1.TabIndex = 5;
            this.radioButtonO1.TabStop = true;
            this.radioButtonO1.Text = "radioButton1";
            this.radioButtonO1.UseVisualStyleBackColor = true;
            this.radioButtonO1.CheckedChanged += new System.EventHandler(this.radioButtonO1_CheckedChanged);
            // 
            // radioButtonO2
            // 
            this.radioButtonO2.AutoSize = true;
            this.radioButtonO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonO2.Location = new System.Drawing.Point(75, 286);
            this.radioButtonO2.Name = "radioButtonO2";
            this.radioButtonO2.Size = new System.Drawing.Size(133, 28);
            this.radioButtonO2.TabIndex = 6;
            this.radioButtonO2.TabStop = true;
            this.radioButtonO2.Text = "radioButton2";
            this.radioButtonO2.UseVisualStyleBackColor = true;
            this.radioButtonO2.CheckedChanged += new System.EventHandler(this.radioButtonO2_CheckedChanged);
            // 
            // radioButtonO3
            // 
            this.radioButtonO3.AutoSize = true;
            this.radioButtonO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonO3.Location = new System.Drawing.Point(76, 329);
            this.radioButtonO3.Name = "radioButtonO3";
            this.radioButtonO3.Size = new System.Drawing.Size(133, 28);
            this.radioButtonO3.TabIndex = 7;
            this.radioButtonO3.TabStop = true;
            this.radioButtonO3.Text = "radioButton3";
            this.radioButtonO3.UseVisualStyleBackColor = true;
            this.radioButtonO3.CheckedChanged += new System.EventHandler(this.radioButtonO3_CheckedChanged);
            // 
            // radioButtonO4
            // 
            this.radioButtonO4.AutoSize = true;
            this.radioButtonO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButtonO4.Location = new System.Drawing.Point(75, 371);
            this.radioButtonO4.Name = "radioButtonO4";
            this.radioButtonO4.Size = new System.Drawing.Size(133, 28);
            this.radioButtonO4.TabIndex = 8;
            this.radioButtonO4.TabStop = true;
            this.radioButtonO4.Text = "radioButton4";
            this.radioButtonO4.UseVisualStyleBackColor = true;
            this.radioButtonO4.CheckedChanged += new System.EventHandler(this.radioButtonO4_CheckedChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.RoyalBlue;
            this.progressBar1.Enabled = false;
            this.progressBar1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.progressBar1.Location = new System.Drawing.Point(75, 116);
            this.progressBar1.Maximum = 12;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(442, 29);
            this.progressBar1.Step = 1;
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.progressBar1.TabIndex = 9;
            // 
            // buttonSLV
            // 
            this.buttonSLV.BackColor = System.Drawing.Color.White;
            this.buttonSLV.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonSLV.Location = new System.Drawing.Point(460, 510);
            this.buttonSLV.Name = "buttonSLV";
            this.buttonSLV.Size = new System.Drawing.Size(183, 58);
            this.buttonSLV.TabIndex = 10;
            this.buttonSLV.Text = "Следующий вопрос";
            this.buttonSLV.UseVisualStyleBackColor = false;
            this.buttonSLV.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1Number
            // 
            this.label1Number.AutoSize = true;
            this.label1Number.BackColor = System.Drawing.Color.White;
            this.label1Number.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1Number.Location = new System.Drawing.Point(1053, -2);
            this.label1Number.Name = "label1Number";
            this.label1Number.Size = new System.Drawing.Size(109, 24);
            this.label1Number.TabIndex = 11;
            this.label1Number.Text = "Опрос № - ";
            // 
            // checkBoxO1
            // 
            this.checkBoxO1.AutoSize = true;
            this.checkBoxO1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxO1.Location = new System.Drawing.Point(898, 54);
            this.checkBoxO1.Name = "checkBoxO1";
            this.checkBoxO1.Size = new System.Drawing.Size(123, 28);
            this.checkBoxO1.TabIndex = 12;
            this.checkBoxO1.Text = "checkBox1";
            this.checkBoxO1.UseVisualStyleBackColor = true;
            this.checkBoxO1.CheckedChanged += new System.EventHandler(this.checkBoxO1_CheckedChanged);
            // 
            // checkBoxO2
            // 
            this.checkBoxO2.AutoSize = true;
            this.checkBoxO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxO2.Location = new System.Drawing.Point(898, 97);
            this.checkBoxO2.Name = "checkBoxO2";
            this.checkBoxO2.Size = new System.Drawing.Size(123, 28);
            this.checkBoxO2.TabIndex = 13;
            this.checkBoxO2.Text = "checkBox2";
            this.checkBoxO2.UseVisualStyleBackColor = true;
            this.checkBoxO2.CheckedChanged += new System.EventHandler(this.checkBoxO2_CheckedChanged);
            // 
            // checkBoxO3
            // 
            this.checkBoxO3.AutoSize = true;
            this.checkBoxO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxO3.Location = new System.Drawing.Point(898, 141);
            this.checkBoxO3.Name = "checkBoxO3";
            this.checkBoxO3.Size = new System.Drawing.Size(123, 28);
            this.checkBoxO3.TabIndex = 14;
            this.checkBoxO3.Text = "checkBox3";
            this.checkBoxO3.UseVisualStyleBackColor = true;
            this.checkBoxO3.CheckedChanged += new System.EventHandler(this.checkBoxO3_CheckedChanged);
            // 
            // checkBoxO4
            // 
            this.checkBoxO4.AutoSize = true;
            this.checkBoxO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxO4.Location = new System.Drawing.Point(898, 182);
            this.checkBoxO4.Name = "checkBoxO4";
            this.checkBoxO4.Size = new System.Drawing.Size(123, 28);
            this.checkBoxO4.TabIndex = 15;
            this.checkBoxO4.Text = "checkBox4";
            this.checkBoxO4.UseVisualStyleBackColor = true;
            this.checkBoxO4.CheckedChanged += new System.EventHandler(this.checkBoxO4_CheckedChanged);
            // 
            // checkBoxO5
            // 
            this.checkBoxO5.AutoSize = true;
            this.checkBoxO5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBoxO5.Location = new System.Drawing.Point(75, 417);
            this.checkBoxO5.Name = "checkBoxO5";
            this.checkBoxO5.Size = new System.Drawing.Size(123, 28);
            this.checkBoxO5.TabIndex = 16;
            this.checkBoxO5.Text = "checkBox4";
            this.checkBoxO5.UseVisualStyleBackColor = true;
            this.checkBoxO5.CheckedChanged += new System.EventHandler(this.checkBoxO5_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(61, 591);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 29);
            this.textBox1.TabIndex = 17;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // labelO1
            // 
            this.labelO1.AutoSize = true;
            this.labelO1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.labelO1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelO1.Location = new System.Drawing.Point(916, 243);
            this.labelO1.Name = "labelO1";
            this.labelO1.Size = new System.Drawing.Size(60, 24);
            this.labelO1.TabIndex = 18;
            this.labelO1.Text = "label1";
            // 
            // labelO2
            // 
            this.labelO2.AutoSize = true;
            this.labelO2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.labelO2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelO2.Location = new System.Drawing.Point(916, 286);
            this.labelO2.Name = "labelO2";
            this.labelO2.Size = new System.Drawing.Size(60, 24);
            this.labelO2.TabIndex = 19;
            this.labelO2.Text = "label1";
            // 
            // labelO3
            // 
            this.labelO3.AutoSize = true;
            this.labelO3.BackColor = System.Drawing.SystemColors.HighlightText;
            this.labelO3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelO3.Location = new System.Drawing.Point(916, 329);
            this.labelO3.Name = "labelO3";
            this.labelO3.Size = new System.Drawing.Size(60, 24);
            this.labelO3.TabIndex = 20;
            this.labelO3.Text = "label1";
            // 
            // labelO4
            // 
            this.labelO4.AutoSize = true;
            this.labelO4.BackColor = System.Drawing.SystemColors.HighlightText;
            this.labelO4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelO4.Location = new System.Drawing.Point(916, 371);
            this.labelO4.Name = "labelO4";
            this.labelO4.Size = new System.Drawing.Size(60, 24);
            this.labelO4.TabIndex = 21;
            this.labelO4.Text = "label1";
            // 
            // labelO5
            // 
            this.labelO5.AutoSize = true;
            this.labelO5.BackColor = System.Drawing.SystemColors.HighlightText;
            this.labelO5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelO5.Location = new System.Drawing.Point(916, 417);
            this.labelO5.Name = "labelO5";
            this.labelO5.Size = new System.Drawing.Size(60, 24);
            this.labelO5.TabIndex = 22;
            this.labelO5.Text = "label1";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox1.Location = new System.Drawing.Point(373, 239);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(42, 28);
            this.comboBox1.TabIndex = 23;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox1_KeyPress);
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox2.Location = new System.Drawing.Point(373, 282);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(42, 28);
            this.comboBox2.TabIndex = 24;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            this.comboBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox2_KeyPress);
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox3.Location = new System.Drawing.Point(373, 325);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(42, 28);
            this.comboBox3.TabIndex = 25;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            this.comboBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox3_KeyPress);
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox4.Location = new System.Drawing.Point(373, 367);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(42, 28);
            this.comboBox4.TabIndex = 26;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            this.comboBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox4_KeyPress);
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox5.Location = new System.Drawing.Point(373, 413);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(42, 28);
            this.comboBox5.TabIndex = 27;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            this.comboBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox5_KeyPress);
            // 
            // label1V
            // 
            this.label1V.AutoSize = true;
            this.label1V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.label1V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1V.Location = new System.Drawing.Point(421, 417);
            this.label1V.Name = "label1V";
            this.label1V.Size = new System.Drawing.Size(60, 24);
            this.label1V.TabIndex = 32;
            this.label1V.Text = "label1";
            // 
            // label2V
            // 
            this.label2V.AutoSize = true;
            this.label2V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.label2V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2V.Location = new System.Drawing.Point(421, 371);
            this.label2V.Name = "label2V";
            this.label2V.Size = new System.Drawing.Size(60, 24);
            this.label2V.TabIndex = 31;
            this.label2V.Text = "label1";
            // 
            // label3V
            // 
            this.label3V.AutoSize = true;
            this.label3V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.label3V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3V.Location = new System.Drawing.Point(421, 329);
            this.label3V.Name = "label3V";
            this.label3V.Size = new System.Drawing.Size(60, 24);
            this.label3V.TabIndex = 30;
            this.label3V.Text = "label1";
            // 
            // label4V
            // 
            this.label4V.AutoSize = true;
            this.label4V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.label4V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4V.Location = new System.Drawing.Point(421, 286);
            this.label4V.Name = "label4V";
            this.label4V.Size = new System.Drawing.Size(60, 24);
            this.label4V.TabIndex = 29;
            this.label4V.Text = "label1";
            // 
            // label5V
            // 
            this.label5V.AutoSize = true;
            this.label5V.BackColor = System.Drawing.SystemColors.HighlightText;
            this.label5V.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5V.Location = new System.Drawing.Point(421, 243);
            this.label5V.Name = "label5V";
            this.label5V.Size = new System.Drawing.Size(60, 24);
            this.label5V.TabIndex = 28;
            this.label5V.Text = "label1";
            // 
            // buttonZT
            // 
            this.buttonZT.BackColor = System.Drawing.Color.SpringGreen;
            this.buttonZT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonZT.Location = new System.Drawing.Point(658, 510);
            this.buttonZT.Name = "buttonZT";
            this.buttonZT.Size = new System.Drawing.Size(183, 58);
            this.buttonZT.TabIndex = 33;
            this.buttonZT.Text = "Завершить";
            this.buttonZT.UseVisualStyleBackColor = false;
            this.buttonZT.Click += new System.EventHandler(this.buttonZT_Click);
            // 
            // chartRes
            // 
            chartArea1.Name = "ChartArea1";
            this.chartRes.ChartAreas.Add(chartArea1);
            legend1.Alignment = System.Drawing.StringAlignment.Center;
            legend1.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Left;
            legend1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            legend1.IsTextAutoFit = false;
            legend1.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Column;
            legend1.Name = "Legend1";
            this.chartRes.Legends.Add(legend1);
            this.chartRes.Location = new System.Drawing.Point(75, 231);
            this.chartRes.Name = "chartRes";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            series1.Legend = "Legend1";
            series1.MarkerBorderColor = System.Drawing.Color.Transparent;
            series1.Name = "Series1";
            this.chartRes.Series.Add(series1);
            this.chartRes.Size = new System.Drawing.Size(892, 333);
            this.chartRes.TabIndex = 35;
            this.chartRes.Text = "chart1";
            // 
            // buttonPrint
            // 
            this.buttonPrint.BackColor = System.Drawing.Color.Salmon;
            this.buttonPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonPrint.Location = new System.Drawing.Point(460, 591);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new System.Drawing.Size(174, 57);
            this.buttonPrint.TabIndex = 36;
            this.buttonPrint.Text = "Распечатать результат";
            this.buttonPrint.UseVisualStyleBackColor = false;
            this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1160, 661);
            this.Controls.Add(this.buttonPrint);
            this.Controls.Add(this.chartRes);
            this.Controls.Add(this.buttonZT);
            this.Controls.Add(this.label1V);
            this.Controls.Add(this.label2V);
            this.Controls.Add(this.label3V);
            this.Controls.Add(this.label4V);
            this.Controls.Add(this.label5V);
            this.Controls.Add(this.comboBox5);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.labelO5);
            this.Controls.Add(this.labelO4);
            this.Controls.Add(this.labelO3);
            this.Controls.Add(this.labelO2);
            this.Controls.Add(this.labelO1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.checkBoxO5);
            this.Controls.Add(this.checkBoxO4);
            this.Controls.Add(this.checkBoxO3);
            this.Controls.Add(this.checkBoxO2);
            this.Controls.Add(this.checkBoxO1);
            this.Controls.Add(this.label1Number);
            this.Controls.Add(this.buttonSLV);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.radioButtonO4);
            this.Controls.Add(this.radioButtonO3);
            this.Controls.Add(this.radioButtonO2);
            this.Controls.Add(this.radioButtonO1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labelNumVopros);
            this.Controls.Add(this.labelVopros);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.ShowIcon = false;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartRes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelVopros;
        private System.Windows.Forms.Label labelNumVopros;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.RadioButton radioButtonO1;
        private System.Windows.Forms.RadioButton radioButtonO2;
        private System.Windows.Forms.RadioButton radioButtonO3;
        private System.Windows.Forms.RadioButton radioButtonO4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button buttonSLV;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1Number;
        private System.Windows.Forms.CheckBox checkBoxO1;
        private System.Windows.Forms.CheckBox checkBoxO2;
        private System.Windows.Forms.CheckBox checkBoxO3;
        private System.Windows.Forms.CheckBox checkBoxO4;
        private System.Windows.Forms.CheckBox checkBoxO5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelO1;
        private System.Windows.Forms.Label labelO2;
        private System.Windows.Forms.Label labelO3;
        private System.Windows.Forms.Label labelO4;
        private System.Windows.Forms.Label labelO5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label1V;
        private System.Windows.Forms.Label label2V;
        private System.Windows.Forms.Label label3V;
        private System.Windows.Forms.Label label4V;
        private System.Windows.Forms.Label label5V;
        private System.Windows.Forms.Button buttonZT;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartRes;
        private System.Windows.Forms.Button buttonPrint;
    }
}