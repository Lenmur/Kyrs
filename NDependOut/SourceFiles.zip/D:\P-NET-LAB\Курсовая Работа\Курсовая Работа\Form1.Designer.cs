﻿namespace Курсовая_Работа
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.наГлавнуюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.тестированиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закрытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelText1 = new System.Windows.Forms.Label();
            this.labelText2 = new System.Windows.Forms.Label();
            this.labelForm = new System.Windows.Forms.Label();
            this.ProitiTest = new System.Windows.Forms.Button();
            this.labelText3 = new System.Windows.Forms.Label();
            this.LabelData = new System.Windows.Forms.Label();
            this.ГлавнаяКартинка = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ГлавнаяКартинка)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Blue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.наГлавнуюToolStripMenuItem,
            this.тестированиеToolStripMenuItem,
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem,
            this.закрытьToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1164, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // наГлавнуюToolStripMenuItem
            // 
            this.наГлавнуюToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.наГлавнуюToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.наГлавнуюToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.наГлавнуюToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("наГлавнуюToolStripMenuItem.Image")));
            this.наГлавнуюToolStripMenuItem.Name = "наГлавнуюToolStripMenuItem";
            this.наГлавнуюToolStripMenuItem.Size = new System.Drawing.Size(121, 25);
            this.наГлавнуюToolStripMenuItem.Text = "На главную";
            this.наГлавнуюToolStripMenuItem.Click += new System.EventHandler(this.наГлавнуюToolStripMenuItem_Click);
            // 
            // тестированиеToolStripMenuItem
            // 
            this.тестированиеToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.тестированиеToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.тестированиеToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("тестированиеToolStripMenuItem.Image")));
            this.тестированиеToolStripMenuItem.Name = "тестированиеToolStripMenuItem";
            this.тестированиеToolStripMenuItem.Size = new System.Drawing.Size(137, 25);
            this.тестированиеToolStripMenuItem.Text = "Тестирование";
            // 
            // посмотретьПредыдущиеРезультатыToolStripMenuItem
            // 
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("посмотретьПредыдущиеРезультатыToolStripMenuItem.Image")));
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Name = "посмотретьПредыдущиеРезультатыToolStripMenuItem";
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Size = new System.Drawing.Size(306, 25);
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Text = "Посмотреть предыдущие результаты";
            this.посмотретьПредыдущиеРезультатыToolStripMenuItem.Click += new System.EventHandler(this.посмотретьПредыдущиеРезультатыToolStripMenuItem_Click);
            // 
            // закрытьToolStripMenuItem
            // 
            this.закрытьToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.закрытьToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.закрытьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("закрытьToolStripMenuItem.Image")));
            this.закрытьToolStripMenuItem.Name = "закрытьToolStripMenuItem";
            this.закрытьToolStripMenuItem.Size = new System.Drawing.Size(98, 25);
            this.закрытьToolStripMenuItem.Text = "Закрыть";
            this.закрытьToolStripMenuItem.Click += new System.EventHandler(this.закрытьToolStripMenuItem_Click);
            // 
            // labelText1
            // 
            this.labelText1.AutoSize = true;
            this.labelText1.BackColor = System.Drawing.Color.LightYellow;
            this.labelText1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelText1.Location = new System.Drawing.Point(27, 165);
            this.labelText1.Name = "labelText1";
            this.labelText1.Size = new System.Drawing.Size(455, 25);
            this.labelText1.TabIndex = 2;
            this.labelText1.Text = "Каков ваш уровень цифровой грамотности?";
            // 
            // labelText2
            // 
            this.labelText2.AutoSize = true;
            this.labelText2.BackColor = System.Drawing.Color.LightYellow;
            this.labelText2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelText2.Location = new System.Drawing.Point(26, 202);
            this.labelText2.Name = "labelText2";
            this.labelText2.Size = new System.Drawing.Size(832, 75);
            this.labelText2.TabIndex = 3;
            this.labelText2.Text = resources.GetString("labelText2.Text");
            // 
            // labelForm
            // 
            this.labelForm.AutoSize = true;
            this.labelForm.BackColor = System.Drawing.Color.RoyalBlue;
            this.labelForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelForm.Location = new System.Drawing.Point(408, 40);
            this.labelForm.Name = "labelForm";
            this.labelForm.Size = new System.Drawing.Size(347, 74);
            this.labelForm.TabIndex = 5;
            this.labelForm.Text = "Цифровая грамотность\r\n2023";
            this.labelForm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ProitiTest
            // 
            this.ProitiTest.BackColor = System.Drawing.Color.Aquamarine;
            this.ProitiTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ProitiTest.Location = new System.Drawing.Point(32, 570);
            this.ProitiTest.Name = "ProitiTest";
            this.ProitiTest.Size = new System.Drawing.Size(227, 73);
            this.ProitiTest.TabIndex = 6;
            this.ProitiTest.Text = "Пройти тест";
            this.ProitiTest.UseVisualStyleBackColor = false;
            this.ProitiTest.Click += new System.EventHandler(this.ProitiTest_Click);
            // 
            // labelText3
            // 
            this.labelText3.AutoSize = true;
            this.labelText3.BackColor = System.Drawing.Color.LightYellow;
            this.labelText3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelText3.Location = new System.Drawing.Point(28, 286);
            this.labelText3.Name = "labelText3";
            this.labelText3.Size = new System.Drawing.Size(964, 72);
            this.labelText3.TabIndex = 7;
            this.labelText3.Text = "В тесте 12 вопросов с выбором ответов. \r\nНеобходимо выбрать один или несколько пр" +
    "авильных ответов. Каждый ответ оцениваться в один балл.\r\nОтвечайте обдуманно, не" +
    " торопитесь.";
            // 
            // LabelData
            // 
            this.LabelData.AutoSize = true;
            this.LabelData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.LabelData.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LabelData.Location = new System.Drawing.Point(941, 29);
            this.LabelData.Name = "LabelData";
            this.LabelData.Size = new System.Drawing.Size(74, 25);
            this.LabelData.TabIndex = 8;
            this.LabelData.Text = "Дата: ";
            // 
            // ГлавнаяКартинка
            // 
            this.ГлавнаяКартинка.Image = ((System.Drawing.Image)(resources.GetObject("ГлавнаяКартинка.Image")));
            this.ГлавнаяКартинка.Location = new System.Drawing.Point(0, 25);
            this.ГлавнаяКартинка.Name = "ГлавнаяКартинка";
            this.ГлавнаяКартинка.Size = new System.Drawing.Size(1164, 668);
            this.ГлавнаяКартинка.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ГлавнаяКартинка.TabIndex = 11;
            this.ГлавнаяКартинка.TabStop = false;
            this.ГлавнаяКартинка.Click += new System.EventHandler(this.ГлавнаяКартинка_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PaleGreen;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(85, 369);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(488, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "Для прохождения теста введите ваши данные: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MistyRose;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(27, 415);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 25);
            this.label2.TabIndex = 13;
            this.label2.Text = "ФИО:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(31, 452);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(376, 26);
            this.textBox1.TabIndex = 14;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.MistyRose;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(448, 415);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Возраст:";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericUpDown1.Location = new System.Drawing.Point(444, 450);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(104, 26);
            this.numericUpDown1.TabIndex = 16;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.MistyRose;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(584, 415);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 17;
            this.label4.Text = "Пол:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "муж.",
            "жен."});
            this.comboBox1.Location = new System.Drawing.Point(579, 450);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(62, 28);
            this.comboBox1.TabIndex = 20;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox1_KeyPress);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Yellow;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(28, 494);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(613, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "Перед прохождением тестирования, внимательно ознакомтесь с инструкцией.";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 691);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LabelData);
            this.Controls.Add(this.labelText3);
            this.Controls.Add(this.ProitiTest);
            this.Controls.Add(this.labelForm);
            this.Controls.Add(this.labelText2);
            this.Controls.Add(this.labelText1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.ГлавнаяКартинка);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Опрос ИЦГН";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Click += new System.EventHandler(this.Form1_Click);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ГлавнаяКартинка)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem тестированиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem посмотретьПредыдущиеРезультатыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закрытьToolStripMenuItem;
        private System.Windows.Forms.Label labelText1;
        private System.Windows.Forms.Label labelText2;
        private System.Windows.Forms.Label labelForm;
        private System.Windows.Forms.Button ProitiTest;
        private System.Windows.Forms.Label labelText3;
        private System.Windows.Forms.Label LabelData;
        private System.Windows.Forms.PictureBox ГлавнаяКартинка;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem наГлавнуюToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

