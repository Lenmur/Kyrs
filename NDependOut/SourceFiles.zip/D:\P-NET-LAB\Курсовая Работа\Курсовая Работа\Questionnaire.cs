﻿

namespace Курсовая_Работа
{
    public class Questionnaire
    {
        public int Number_Opros { get; set; }
        public Questionnaire(int no1)
        { 
            Number_Opros = no1; 
        }
    }
}
